// remix icons
import {
  RiYoutubeFill,
  RiInstagramFill,
  RiGithubFill,
  RiLinkedinFill,
} from 'react-icons/ri';

// nav
export const nav = [
  {
    name: 'home',
  },
  {
    name: 'about',
  },
  {
    name: 'contact',
  },
];

// social
export const social = [
  {
    icon: <RiYoutubeFill />,
    href: '',
  },
  {
    icon: <RiInstagramFill />,
    href: '',
  },
  {
    icon: <RiGithubFill />,
    href: '',
  },
  {
    icon: <RiLinkedinFill />,
    href: '',
  },
];

// about
export const about = {
  title: 'About me',
  subtitle:
    'I am a beginner frontend developer. I do my best to develop websites with an emphasis on aesthetics.',
};

// contact
export const contact = {
  title: 'Contact.',
  subtitle: 'Feel free to contact me.',
};
